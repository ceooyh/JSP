package config;
public interface DBConfig {
	public String DB_DRIVER = "oracle.jdbc.OracleDriver";
	public String DB_URL = "jdbc:oracle:thin:@175.197.213.135:32769:xe";
	public String DB_USER = "scott";
	public String DB_PASS= "tiger";
}
