package controller;

public interface Controller {
	public void excute();
}
