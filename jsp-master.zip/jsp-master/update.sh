git add MemberProject
git commit -m "자동 커밋"
git push -u origin master

